#pragma once 

static bool Esp = false;
static bool ESPLine = false;
static bool ESPBox = false; 
static bool Esphealth = false;
static bool EspPoint = false;
static bool EspObject = false;
static float Box = 0;
float density = -1;
ImVec4 ESPLineColor = ImVec4(255.0f, 0.0f, 0.0f, 1.00f);
ImVec4 ESPBoxColor = ImVec4(255.0f, 0.0f, 0.0f, 1.00f);
float ESPLineSize = 5.0f,ESPBoxSize = 5.0f;
float fuck = 1.0f;
bool Test;